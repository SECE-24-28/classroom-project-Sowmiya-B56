function EditStudent(){
    return(
        <>
         <h1>Edit Student</h1>
        </>
    )
}
export default EditStudent;