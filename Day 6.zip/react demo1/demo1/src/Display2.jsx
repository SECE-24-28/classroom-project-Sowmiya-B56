//this code is about page rerender
/*import { useState } from "react"

const Display2=()=>{
    const [name,setName]=useState("")
    console.log("the data is....",name)
    return(
        <>
        <h1>im from display2</h1>
        <input type="text" onChange={(e)=>{setName(e.target.value)}}></input>
        <button onClick={()=>{setName("")}}>Clear</button>
        </>
    )
}
export default Display2 */








//this page is about page not rerendor when click is clicked then only the text is showed
import { useRef, useState } from "react"
const Display2=()=>{
    const [name,setName]=useState("")
    const input=useRef()
    const view=()=>{
        console.log("the data is: ",input.current.value)
        setName(input.current.value)
    }
      return(
        <>
        <h1>im from dis2(2) {name}</h1>
        <h2>input:{input.current?.value}</h2>
        <input type="text" ref={input}></input>
        <button onClick={view}>click</button>
        </>
          )
}
export default Display2