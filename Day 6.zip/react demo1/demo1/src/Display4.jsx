//to print student name,gender,phone number using state variables
import { useState } from "react"

const Display4 = () => {
    const [data, setData] = useState(100)
    const [name, setName] = useState("")
    const [gender, setGender] = useState("")
    const [contact, setContact] = useState("")

    return (
        <>
            <h1>I'm from Display4</h1>

           
            <h2>The data: {data}</h2>
            <button onClick={() => setData(t => t + 1)}>
                Increment
            </button>

            <hr />

            
            <h2>Enter Student Details</h2>

            <label>Name: </label>
            <input 
                type="text" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
            />
            <br /><br />

            <label>Gender: </label>
            <input 
                type="text" 
                value={gender} 
                onChange={(e) => setGender(e.target.value)} 
            />
            <br /><br />

            <label>Contact: </label>
            <input 
                type="text" 
                value={contact} 
                onChange={(e) => setContact(e.target.value)} 
            />
            <br /><br />

            <hr />

            
            <h2>Student Details Output</h2>
            <p><b>Name:</b> {name}</p>
            <p><b>Gender:</b> {gender}</p>
            <p><b>Contact:</b> {contact}</p>
        </>
    )
}

export default Display4
