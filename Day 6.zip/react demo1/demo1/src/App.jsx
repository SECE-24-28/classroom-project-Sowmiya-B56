import { createContext,useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Display from './Display';
import Display1 from './Display1';
export const allDatas=createContext()

function App() {
  const[data,setData]=useState();
  var name="demo";
  var val1=23;
  //const arr=[12,23,34]
  var arr=[12,34,5]
  const person={name:"sowmi",gender:"female"}
  const receive=(d)=>{
    console.log("got it",d)
    setData(d)
  }
  return(
    <allDatas.Provider value={{name,val1,person,receive,arr}}>
    <h1>welcome</h1>
    <h1>i've received from parent{data}</h1>
    <h1>......................</h1>
  {/*<Display name={name} a={val1} arr={arr} obj={person} receive={receive}/> */}
    <Display/>
    </allDatas.Provider>

  )
 /*import { useState } from "react"

function Display1(datas){
    const {val}=datas;
    
    const [myName,setMyName]= useState("hello")
 
    console.log("im inside the disp1",{myName})
   
    return(
        <>
        <h1>im from dis1{myName}</h1>
        <h1>i've recevied from myGP thru my Parent {val}
             
        </h1>
<button onClick={()=>{setMyName('not demo')}}>click here!!!!</button>
</>
    )
}

export default Display1 */
  /*const [count, setCount] = useState(0)
   <Display1/>
   <Display name={name} a={val1} arr={arr} obj={person}/>
  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <p>
          Edit <code>src/App.jsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  )*/
}

export default App
