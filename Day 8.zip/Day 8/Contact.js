const Contact=()=>{
    return(
    <>
    <h1>I'm in Contact</h1>
    </>)
}
export default Contact;