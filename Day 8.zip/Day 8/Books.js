const Books=()=>{
    return(
    <>
    <h1>I'm in Books</h1>
    </>)
}
export default Books;