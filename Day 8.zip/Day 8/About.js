const About=()=>{
    return(
    <>
    <h1>I'm in About</h1>
    </>)
}
export default About;