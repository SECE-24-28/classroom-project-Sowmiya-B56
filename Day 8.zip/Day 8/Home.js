const Home1=()=>{
    return(
    <>
    <h1>I'm in Home</h1>
    </>)
}
export default Home1;